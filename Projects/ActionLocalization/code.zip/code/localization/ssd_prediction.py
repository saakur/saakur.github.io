from keras import backend as K
from keras.models import load_model
from keras.preprocessing import image
from keras.optimizers import Adam
from scipy.misc import imread
import numpy as np
from matplotlib import pyplot as plt

from keras.preprocessing import image as image_utils
from keras_ssd512 import ssd_512
from keras_ssd_loss import SSDLoss
from keras_layer_AnchorBoxes import AnchorBoxes
from keras_layer_L2Normalization import L2Normalization
from ssd_box_encode_decode_utils import decode_y, decode_y2
from ssd_batch_generator import BatchGenerator

import cv2
import sys, os
import matplotlib.pyplot as plt
from os import listdir
from os.path import isfile, join, isdir
from random import shuffle, choice
from PIL import Image
import imageio

anchors = [(10,13), (16,30), (33,23), (30,61), (62,45), (59,119), (116,90), (156,198), (373,326)]

def non_max_suppression_fast(boxes, overlapThresh):
	# if there are no boxes, return an empty list
	if len(boxes) == 0:
		return []
	# if the bounding boxes integers, convert them to floats --
	# this is important since we'll be doing a bunch of divisions
	if boxes.dtype.kind == "i":
		boxes = boxes.astype("float")
	# initialize the list of picked indexes 
	pick = []
	# grab the coordinates of the bounding boxes
	x1 = boxes[:,0]
	y1 = boxes[:,1]
	x2 = boxes[:,2]
	y2 = boxes[:,3]
	# compute the area of the bounding boxes and sort the bounding
	# boxes by the bottom-right y-coordinate of the bounding box
	area = (x2 - x1 + 1) * (y2 - y1 + 1)
	idxs = np.argsort(y2)
	# keep looping while some indexes still remain in the indexes
	# list
	while len(idxs) > 0:
		# grab the last index in the indexes list and add the
		# index value to the list of picked indexes
		last = len(idxs) - 1
		i = idxs[last]
		pick.append(i)
		# find the largest (x, y) coordinates for the start of
		# the bounding box and the smallest (x, y) coordinates
		# for the end of the bounding box
		xx1 = np.maximum(x1[i], x1[idxs[:last]])
		yy1 = np.maximum(y1[i], y1[idxs[:last]])
		xx2 = np.minimum(x2[i], x2[idxs[:last]])
		yy2 = np.minimum(y2[i], y2[idxs[:last]])
		# compute the width and height of the bounding box
		w = np.maximum(0, xx2 - xx1 + 1)
		h = np.maximum(0, yy2 - yy1 + 1)
		# compute the ratio of overlap
		overlap = (w * h) / area[idxs[:last]]
		# delete all indexes from the index list that have
		idxs = np.delete(idxs, np.concatenate(([last],
			np.where(overlap > overlapThresh)[0])))
	# return only the bounding boxes that were picked using the
	# integer data type
	return boxes[pick].astype("int")

def loadMiniBatch(vidFilePath):
	vidName = vidFilePath.split('/')[-3]
	frameList = sorted([join(vidFilePath, f) for f in listdir(vidFilePath) if isfile(join(vidFilePath, f)) and f.endswith('.jpg')])
	frameList = sorted(frameList, key=lambda x: int(x.split('/')[-1].split('.')[0]))
	minibatch = []
	for imFile in frameList:
		img = Image.open(imFile)
		# img = img.resize((input_width, input_height), Image.ANTIALIAS)
		img = np.array(img)
		img = img[:, :, ::-1].copy() 
		minibatch.append(img)
	return minibatch

def bb_intersection_over_union(boxA, boxB):
	# determine the (x, y)-coordinates of the intersection rectangle
	xA = max(boxA[0], boxB[0])
	yA = max(boxA[1], boxB[1])
	xB = min(boxA[2], boxB[2])
	yB = min(boxA[3], boxB[3])
	# compute the area of intersection rectangle
	interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
	# compute the area of both the prediction and ground-truth
	# rectangles
	boxAArea = (boxA[2] - boxA[0] + 1) * (boxA[3] - boxA[1] + 1)
	boxBArea = (boxB[2] - boxB[0] + 1) * (boxB[3] - boxB[1] + 1)
	# compute the intersection over union by taking the intersection
	# area and dividing it by the sum of prediction + ground-truth
	# areas - the interesection area
	iou = interArea / float(boxAArea + boxBArea - interArea)
	# return the intersection over union value
	return iou

def match_anchor(ss_bb, anch_bb, numProp=30):
	# bestIoU = 0.0
	bestBB1 = []
	for s_bb in ss_bb:
		for a_bb,area in anch_bb:
			iou = bb_intersection_over_union(s_bb, a_bb)/area
			bestBB1.append((s_bb, iou))
	bestBB1 = sorted(bestBB1, key=lambda x:x[1], reverse=True)
	return [x[0] for x in bestBB1[:numProp]]

# Set the image size.
img_height = 512
img_width = 512
newWidth = img_width
newHeight = img_height

# 1: Build the Keras model

K.clear_session() # Clear previous models from memory.

model = ssd_512(image_size=(img_height, img_width, 3),
								n_classes=20,
								l2_regularization=0.0005,
								scales=[0.04, 0.1, 0.26, 0.42, 0.58, 0.74, 0.9, 1.06],
								aspect_ratios_per_layer=[[1.0, 2.0, 0.5],
																				 [1.0, 2.0, 0.5, 3.0, 1.0/3.0],
																				 [1.0, 2.0, 0.5, 3.0, 1.0/3.0],
																				 [1.0, 2.0, 0.5, 3.0, 1.0/3.0],
																				 [1.0, 2.0, 0.5, 3.0, 1.0/3.0],
																				 [1.0, 2.0, 0.5],
																				 [1.0, 2.0, 0.5]],
							 two_boxes_for_ar1=True,
							 steps=[8, 16, 32, 64, 128, 256, 512],
							 offsets=[0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
							 limit_boxes=False,
							 variances=[0.1, 0.1, 0.2, 0.2],
							 coords='centroids',
							 normalize_coords=True,
							 subtract_mean=[123, 117, 104],
							 swap_channels=True)

# 2: Load the trained weights into the model.

# TODO: Set the path of the trained weights.

weights_path = './VGG_coco_SSD_512x512.h5'

model.load_weights(weights_path, by_name=True)

# 3: Compile the model so that Keras won't complain the next time you load it.

adam = Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=5e-04)

ssd_loss = SSDLoss(neg_pos_ratio=3, n_neg_min=0, alpha=1.0)

model.compile(optimizer=adam, loss=ssd_loss.compute_loss)

# imgs = loadMiniBatch(sys.argv[1])

classes = ['background', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor']

cv2.setUseOptimized(True);
cv2.setNumThreads(-1);

attn_path = sys.argv[1]
logFile = sys.argv[2]
attn_files = [join(attn_path,l) for l in listdir(attn_path)]

for attn_file in attn_files:
	# attn_file = "/home/saakur/Desktop/Spatial-temporal-detection/ucf_sports_output/Walk-Front_002.txt"
	if "SkateBoarding-Front_001" not in attn_file:
		continue
	gtPath = "/media/4TBHDD/Datasets/UCF_Sports/videos/"
	gtFile = os.path.join(gtPath, '/'.join(attn_file.split(os.sep)[-1].split('.')[0].split('_')), 'gt')
	if not os.path.exists( gtFile):
		continue
	vidFilePath = os.path.join(gtPath, '/'.join(attn_file.split(os.sep)[-1].split('.')[0].split('_')), 'frames')
	imgs = loadMiniBatch(vidFilePath)
	gtBBs = []
	for annotFile in sorted(listdir(gtFile)):
		with open(join(gtFile,annotFile), 'r') as f:
			for line in f:
				gtBBs.append([int(l) for l in line.split('\t')[:-1]])
	attention_points = []
	with open(attn_file, 'r') as f:
		for line in f:
			attention_points.append([int(l) for l in line.replace('\n', '').split('\t')[1:]])
	if len(gtBBs) != len(attention_points):
		print(gtFile, len(imgs), len(gtBBs), len(attention_points))
		while len(attention_points) < len(gtBBs):
			attention_points.append(attention_points[-1])
	# print(attention_points)
	print(gtFile, len(imgs), len(gtBBs), len(attention_points))
	# sys.exit(0)
	# attention_points = [[0, 10, 8, 0], [0, 9, 9, 0], [0, 11, 11, 0], [0, 11, 11, 0], [0, 12, 10, 0], [0, 9, 6, 0], [0, 5, 5, 0], [0, 10, 7, 0], [0, 5, 3, 0], [0, 9, 6, 0], [0, 9, 8, 0], [0, 10, 7, 0], [0, 10, 7, 0], [0, 10, 7, 0], [0, 9, 7, 0], [0, 9, 7, 0], [0, 9, 6, 0], [0, 9, 6, 0], [0, 10, 6, 0], [0, 9, 6, 0], [0, 9, 6, 0], [0, 9, 6, 0], [0, 6, 3, 0], [0, 9, 5, 0], [0, 8, 5, 0], [0, 8, 5, 0], [0, 9, 6, 0], [0, 9, 6, 0], [0, 9, 4, 0], [0, 8, 5, 0], [0, 7, 3, 0], [0, 7, 3, 0], [0, 9, 5, 0], [0, 9, 5, 0], [0, 9, 4, 0], [0, 7, 3, 0], [0, 7, 3, 0], [0, 5, 3, 0], [0, 6, 3, 0], [0, 9, 4, 0], [0, 6, 3, 0], [0, 8, 5, 0], [0, 8, 5, 0], [0, 7, 3, 0], [0, 7, 3, 0], [0, 8, 4, 0], [0, 8, 4, 0], [0, 8, 5, 0], [0, 8, 4, 0], [0, 5, 3, 0], [0, 6, 3, 0], [0, 6, 3, 0], [0, 9, 4, 0], [0, 8, 4, 0], [0, 5, 4, 0], [0, 8, 4, 0], [0, 5, 4, 0], [0, 8, 4, 0], [0, 8, 4, 0], [0, 8, 4, 0], [0, 8, 4, 0], [0, 8, 5, 0], [0, 7, 4, 0], [0, 7, 4, 0], [0, 7, 4, 0], [0, 7, 4, 0], [0, 7, 5, 0], [0, 5, 4, 0], [0, 5, 4, 0]]
	# gtBBs = [[296, 37, 120, 296], [287, 44, 122, 290], [276, 53, 132, 275], [278, 51, 122, 280], [272, 59, 124, 270], [260, 55, 133, 268], [255, 51, 121, 268], [243, 55, 109, 263], [237, 54, 104, 260], [235, 52, 97, 259], [223, 45, 97, 265], [206, 49, 101, 252], [208, 41, 101, 262], [202, 43, 101, 254], [189, 45, 109, 248], [183, 39, 115, 258], [186, 40, 114, 260], [171, 41, 125, 247], [179, 48, 111, 242], [174, 42, 115, 245], [163, 53, 121, 233], [162, 64, 108, 222], [165, 68, 102, 217], [160, 68, 92, 218], [157, 77, 88, 206], [159, 76, 85, 208], [157, 76, 83, 202], [146, 77, 87, 198], [147, 73, 80, 198], [140, 71, 88, 201], [141, 75, 80, 194], [138, 72, 76, 198], [141, 71, 72, 193], [135, 70, 82, 196], [138, 70, 74, 193], [128, 63, 81, 200], [131, 67, 76, 193], [130, 70, 69, 191], [124, 69, 78, 190], [122, 70, 84, 188], [118, 74, 84, 186], [120, 74, 82, 183], [121, 73, 79, 184], [124, 70, 75, 188], [119, 73, 78, 180], [120, 74, 75, 181], [121, 77, 70, 173], [122, 79, 67, 172], [121, 79, 72, 170], [118, 79, 72, 171], [116, 75, 68, 173], [120, 81, 65, 165], [116, 84, 64, 161], [114, 79, 67, 170], [117, 85, 65, 158], [115, 92, 68, 152], [122, 93, 63, 153], [119, 98, 64, 144], [115, 99, 65, 142], [116, 95, 65, 147], [115, 102, 60, 138], [120, 99, 53, 143], [114, 99, 56, 142], [113, 95, 60, 139], [117, 96, 52, 139], [114, 95, 49, 144], [112, 99, 51, 131], [109, 98, 54, 135], [107, 91, 59, 137]]
	ious = []
	recall = 0
	# with imageio.get_writer('./detect.gif', mode='I') as writer:
	for orig, attnVal,gt_bb in zip(imgs, attention_points,gtBBs):
		# print(attnVal, gt_bb)
		gridW, gridH = int(512/14), int(512/14)
		predY = (attnVal[1])*gridH + int(0.5*gridH)
		predX = (attnVal[2])*gridW + int(0.5*gridW)
		# print(predX, predY)
		ori_height, ori_width, _ = orig.shape
		resized_image = cv2.resize(orig, (img_width, img_height))		
		img = image.img_to_array(resized_image)		
		input_images = np.expand_dims(np.array(img), axis=0)
		y_pred = model.predict(input_images)
		y_pred_decoded = decode_y(y_pred, confidence_thresh=0.01, iou_threshold=0.45, top_k=200, input_coords='centroids', normalize_coords=True, img_height=img_height, img_width=img_width)
		rects = []
		for box in y_pred_decoded[0]:
			xmin = box[-4]# * orig.shape[1] / img_width
			ymin = box[-3]# * orig.shape[0] / img_height
			xmax = box[-2]# * orig.shape[1] / img_width
			ymax = box[-1]# * orig.shape[0] / img_height

			# font = cv2.FONT_HERSHEY_SIMPLEX
			# cv2.putText(orig, classes[int(box[0])], (int(xmin),int(ymin-8)), font, 0.5, (255,255,255), 2, cv2.LINE_AA)
			# cv2.rectangle(orig,(int(xmin),int(ymin)),(int(xmax),int(ymax)),(0,0,255),3)
			rects.append([int(xmin), int(ymin), int(xmax), int(ymax)])

		
		rects = [[x1, y1, x2, y2] for x1, y1, x2, y2 in rects if x1 < predX < x2 and y1 < predY < y2]
		anch_bb = []
		for w,h in anchors[-3:]:
			anch_bb.append(([int(predX - w/2), int(predY - h/2), int(predX + w/2), int(predY + h/2)], 1))
		# rects = match_anchor(rects, anch_bb, 10)
		# print(rects)
		# rects = non_max_suppression_fast(np.array(rects), 0.99)

		
		imOut = resized_image.copy()

		# itereate over all the region proposals
		x1_gt, y1_gt, w_gt, h_gt = gt_bb 
		ratio_gt1 = newWidth/ori_width
		ratio_gt2 = newHeight/ori_height
		x1_gt = int(x1_gt*ratio_gt1)
		y1_gt = int(y1_gt*ratio_gt2)
		w_gt = int(w_gt*ratio_gt1)
		h_gt = int(h_gt*ratio_gt2)
		# cv2.rectangle(imOut, (x1_gt, y1_gt), (x1_gt + w_gt, y1_gt +h_gt), (255, 0, 0), 2, cv2.LINE_AA)
		# cv2.rectangle(imOut, (predX - 25, predY - 25), (predX + 25, predY + 25), (0, 0, 255), -1, cv2.LINE_AA)

		gt_bb1 = [x1_gt, y1_gt, x1_gt + w_gt, y1_gt+h_gt]
		tempIou = []
		for i, rect in enumerate(rects):
			x, y, x2, y2 = rect
			# cv2.rectangle(imOut, (x, y), (x2, y2), (0, 255, 0), 2, cv2.LINE_AA)
			iou = bb_intersection_over_union(rect, gt_bb1)
			tempIou.append(iou)
		if tempIou:
			ious.append(max(tempIou))
			print("\r", np.mean(tempIou), max(tempIou), np.mean(ious), recall ,end="")
		else:
			ious.append(0)
			print("\r", np.mean(tempIou), 0, np.mean(ious), recall, end="")
		if ious[-1] >= 0.5:
			recall += 1
		
		# plt.imshow(imOut, cmap='gray')
			# plt.show()
			# writer.append_data(imOut)
	with open(logFile, 'a') as of:
		of.write("%s\t%f\t%d\t%d\t%d\n"%(attn_file.split(os.sep)[-1].split('.')[0], np.mean(ious), recall, len(gtBBs), len(ious)))#fileName, mean IOU, recall, gt # BB, pred #BB