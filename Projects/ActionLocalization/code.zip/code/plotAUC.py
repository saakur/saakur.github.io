import os, sys, cv2, json
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as colors
import itertools
def flip(items, ncol):
    return itertools.chain(*[items[i::ncol] for i in range(ncol)])

baselineFile = sys.argv[1]
baselines = json.load(open(baselineFile))
plt.figure(num=None, figsize=(24, 24), dpi=75, facecolor='w', edgecolor='k')
font = {'family' : 'normal',
		'weight' : 'bold',
        'size'   : 42}

plt.rc('font', **font)

plt.style.use('seaborn-whitegrid') 
# colormap = plt.cm.tab20b# ListedColormap
# colormap1 = plt.cm.autumn# ListedColormap
# Ncolors = len(list(baselines.keys()))

# Ncolors = min(colormap.N,Ncolors)
# mapcolors = [colormap(int(x*colormap.N/Ncolors)) for x in range(Ncolors)]
mapcolors = ['cornflowerblue', 'gray', 'yellowgreen', 'darkkhaki', 'skyblue', 'peru', 'darkorange', 'hotpink']
mapcolors2 = ['red', 'magenta', 'blue', 'black', 'yellowgreen']

# N = Ncolors*4+10
colorID = 0
colorID1 = 0
for baseline in baselines.keys():
	label = baseline
	iouThresh = baselines[baseline]["ious"]
	mAP = baselines[baseline]["mAP"]
	if "K_" not in baseline:# or baseline == "Soomro 17":
		l = plt.plot(iouThresh, mAP, label=label, marker="D", color=mapcolors2[colorID1], linewidth=10, ms=25, ls="-")
		l[0].set_clip_on(False)
		colorID1 += 1
	else:
		l = plt.plot(iouThresh, mAP, label=label, marker="v", color=mapcolors[colorID], linewidth=10, ms=25, ls="-")
		l[0].set_clip_on(False)
		colorID += 1
plt.xlim(0.1,0.60)
plt.ylim(0.0,0.65)
plt.xlabel("Overlap Threshold", fontsize=48, weight="bold")
plt.ylabel("AUC", fontsize=48, weight="bold")
plt.grid(b=True, which='major', axis='both',ls="dashdot", clip_on=True)
plt.axes().tick_params(axis='both', which='major', pad=15)
# plt.legend()
handles, labels = plt.axes().get_legend_handles_labels()
plt.legend(flip(handles, 2), flip(labels, 2), ncol=1, loc="lower left", fontsize=32)
plt.gcf().set_size_inches(15, 15)
# plt.axes().spines['bottom'].set_color('0.5')
# plt.axes().spines['top'].set_color('0.5')
# plt.axes().spines['right'].set_color('0.5')
# plt.axes().spines['left'].set_color('0.5')

plt.rcParams["axes.linewidth"] = 2
# plt.rcParams["axes.edgecolor"] = .8
plt.show()