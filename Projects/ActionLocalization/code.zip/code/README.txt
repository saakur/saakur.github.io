We have provided the code to reproduce our results for the paper. Below are instructions to run the framework.

To train:
	python train.py <JSON File with train/test splits> <Video File Path> <Model (to save) File Name>
To test:
	1. Get features per video and Attention predictions.
		python test.py <JSON File with train/test splits> <Video File Path> <TrainedModel Path> <Output path for attention points and features file>
	2. Predict localization proposals.
		SSD: python localization/ssd_prediction.py <Path to attention predictions> <Output log file path>
		EdgeBox: python localization/edgeBoxes_pred.py <Path to attention predictions> <Output log file path>
		Selective Search: python localization/selectiveSearch_pred.py <Path to attention predictions> <Output log file path>
	3. Get labels and quantify video level performance.
		python get_labels.py <path to features file> <Number of Clusters> <File with list of class names> <Log file with IoUs>