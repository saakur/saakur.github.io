import os, sys, cv2
import numpy as np
from eval_metrics import _acc, _original_match, _hungarian_match
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn import mixture
import matplotlib.pyplot as plt
# import seaborn as sns

np.random.seed(1)

featFile = sys.argv[1]
try:
	num_clusters = int(sys.argv[2])
except:
	print("Error setting num_clusters. Defaulting to 20")
	num_clusters = 20
labelFile = sys.argv[3]
iouFile = sys.argv[4]

classes = []
gtLabels = []
features = []
vidNames = []

cAUC = {}
cRAUC = {}
with open(labelFile, 'r') as file:
	for line in file:
		line = line.replace("\n", "")
		classes.append(line)
with open(labelFile, 'r') as file:
	for line in file:
		line = line.replace("\n", "")
		cAUC[classes.index(line)] = {float(k/10):[] for k in range(1,10,1)}
with open(labelFile, 'r') as file:
	for line in file:
		line = line.replace("\n", "")
		cRAUC[classes.index(line)] = {float(k/10):[] for k in range(1,10,1)}
# print(cAUC)
gtClusters = len(classes)

with open(featFile, 'r') as file:
	for line in file:
		line = line.replace("\n", "")
		try:
			vidName, feature = line.split('\t')
		except:
			print(line)
			sys.exit(0)
		feature = np.array([float(m) for m in feature.split(",")])
		gtLabels.append(classes.index(vidName.split('_')[0]))
		features.append(feature)
		vidNames.append(vidName)
ious = [0]*len(vidNames)
with open(iouFile, 'r') as file:
	for line in file:
		line = line.replace("\n", "")
		try:
			vidName, avIoU, _, _, _ = line.split('\t')
		except:
			print(line)
			sys.exit(0)
		ious[vidNames.index(vidName)] = float(avIoU)

print(gtLabels, classes)
print(len(gtLabels), len(features), features[0].shape)

kmeans = KMeans(n_clusters=num_clusters, max_iter=100, n_jobs=-1).fit(features)
flat_predictions = kmeans.labels_
n = len(features)

if num_clusters == gtClusters:
	match = _hungarian_match(np.reshape(flat_predictions, (n,1)), np.reshape(gtLabels, (n,1)), preds_k=num_clusters, targets_k=gtClusters)
else:
	match = _original_match(np.reshape(flat_predictions, (n,1)), np.reshape(gtLabels, (n,1)), preds_k=num_clusters, targets_k=gtClusters)

reordered_preds = np.zeros((n,1))
for pred_i, target_i in match:
	reordered_preds[flat_predictions == pred_i] = target_i
acc1 = _acc(reordered_preds, np.reshape(gtLabels, (n,1)), gtClusters, 0)
from sklearn.metrics.cluster import homogeneity_score
print("Purity:", homogeneity_score(np.reshape(gtLabels,(-1,)), np.reshape(reordered_preds,(-1,))))
print(flat_predictions)
print(match)
print("k-Means Video-level Accuracy", acc1)
AUC = {float(k/10):[] for k in range(1,10,1)}
rAUC = {float(k/10):[] for k in range(1,10,1)}
for pred_cluster,vidName,avIoU in zip(reordered_preds.tolist(),vidNames,ious):
	gtClass = gtLabels[vidNames.index(vidName)]
	for iou in AUC.keys():
		if avIoU >= iou and gtClass == pred_cluster[0]:
			AUC[iou].append(1)
			cAUC[gtClass][iou].append(1)
		else:
			AUC[iou].append(0)
			cAUC[gtClass][iou].append(0)
		if avIoU >= iou:
			rAUC[iou].append(1)
			cRAUC[gtClass][iou].append(1)
		else:
			rAUC[iou].append(0)
			cRAUC[gtClass][iou].append(0)

	if "Lift" in vidName or "Skate"	in vidName:
		print(vidName, classes[int(pred_cluster[0])], avIoU)


AUC = {k:np.mean(v) for k,v in AUC.items()}
print(sum(rAUC[0.5])/len(rAUC[0.5]))
rAUC = {k:np.mean(v) for k,v in rAUC.items()}
# print({classes[k]:v for k,v in cAUC.items()})
# sys.exit(0)
cAUC = {classes[k]:{k1:np.mean(v1) for k1,v1 in v.items() if v1} for k,v in cAUC.items()}
cAUC = {k:v for k,v in cAUC.items() if v}
cRAUC = {classes[k]:{k1:np.mean(v1) for k1,v1 in v.items() if v1} for k,v in cRAUC.items()}
cRAUC = {k:v for k,v in cRAUC.items() if v}
print("k-means AUC", AUC)
print("k-means rAUC", rAUC)
print("k-means cAUC", cAUC)
for k,v in cAUC.items():
	print(k, [np.mean(v1) for k,v1 in v.items()])

for k,v in cRAUC.items():
	print(k, [np.mean(v1) for k,v1 in v.items()])


iouThresh = list(AUC.keys())
mAP = list(AUC.values())

plt.style.use('seaborn') 
plt.plot(iouThresh, mAP)
plt.show()
