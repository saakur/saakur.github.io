from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.tools import inspect_checkpoint as chkp
from tensorflow.python.ops import math_ops
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import nn_ops
from tensorflow.python.ops import init_ops
from tensorflow.python.ops import variable_scope as vs
from tensorflow.python.framework import constant_op
from tensorflow.python.framework import dtypes

import matplotlib.pyplot as plt
import numpy as np
import os
from os import listdir
from os.path import isfile, join, isdir
from random import shuffle, choice
from PIL import Image
import sys
import json
import collections, cv2

def warn(*args, **kwargs):
	pass
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

# tf.set_random_seed(0)

input_width = 224
input_height = 224
num_channels = 3
slim = tf.contrib.slim
n_hidden1 = 512
n_hidden2 = 512
learnError = 0
n_epochs = 1
batch_size = 2

feature_size = 512
attention_shape = 14*14

seq_length = batch_size - 1

statefull_lstm_flag = False

lr_init = 1e-10

def loadData(jsonData, inPath):
	batchPaths = []
	for vidPath1 in jsonData["test_path"]:
		vidPath = join(inPath,vidPath1)
		framePath = os.path.join(os.path.dirname(vidPath), "frames")
		batchPaths = batchPaths + [framePath]
	return batchPaths

def loadMiniBatch(vidFilePath):
	frameList = sorted([join(vidFilePath, f) for f in listdir(vidFilePath) if isfile(join(vidFilePath, f)) and f.endswith('.jpg')])
	frameList = sorted(frameList, key=lambda x: int(x.split('/')[-1].split('.')[0]))
	its = [iter(frameList), iter(frameList[1:])]
	segments = zip(*its)
	minibatch = []
	for segment in segments:
		im = []
		numFrames = 0
		for j, imFile in enumerate(segment):
			img = Image.open(imFile)
			img = img.resize((input_width, input_height), Image.ANTIALIAS)
			img = np.array(img)
			img = img[:, :, ::-1].copy() 
			# img = cv2.GaussianBlur(img,(5,5),0)
			im.append(img)
			numFrames += 1
		minibatch.append(np.stack(im))
	return vidFilePath, minibatch

def broadcast(tensor, shape):
	return tensor + tf.zeros(shape, dtype=tensor.dtype)

def RNNCell(W, B, inputs, state):
	"""Most basic RNN: output = new_state = act(W * input + U * state + B)."""
	one = constant_op.constant(1, dtype=dtypes.int32)
	add = math_ops.add
	multiply = math_ops.multiply
	sigmoid = math_ops.sigmoid
	activation = math_ops.tanh

	gate_inputs = math_ops.matmul(array_ops.concat([inputs, state], 1), W)
	gate_inputs = nn_ops.bias_add(gate_inputs, B)
	output = sigmoid(gate_inputs)
	return output, output

def lstm_cell(W, b, forget_bias, inputs, state):
	one = constant_op.constant(1, dtype=dtypes.int32)
	add = math_ops.add
	multiply = math_ops.multiply
	sigmoid = math_ops.sigmoid
	activation = math_ops.sigmoid
	# activation = math_ops.tanh

	c, h = array_ops.split(value=state, num_or_size_splits=2, axis=one)

	gate_inputs = math_ops.matmul(array_ops.concat([inputs, h], 1), W)
	gate_inputs = nn_ops.bias_add(gate_inputs, b)
	# i = input_gate, j = new_input, f = forget_gate, o = output_gate
	i, j, f, o = array_ops.split(value=gate_inputs, num_or_size_splits=4, axis=one)

	forget_bias_tensor = constant_op.constant(forget_bias, dtype=f.dtype)

	new_c = add(multiply(c, sigmoid(add(f, forget_bias_tensor))), multiply(sigmoid(i), activation(j)))
	new_h = multiply(activation(new_c), sigmoid(o))
	new_state = array_ops.concat([new_c, new_h], 1)

	return new_h, new_state

class RNN_Predictor (tf.keras.Model):
	def __init__(self, batch_input_shape, input_shape, hidden_units):
	  
		super(RNN_Predictor, self).__init__()
	  
		# hidden state
		self.hidden_units = hidden_units
		
		self.hidden_state = tf.zeros((attention_shape, self.hidden_units))
		
		# BahdanauAttention layer to process input
		self.W1 = tf.keras.layers.Dense(hidden_units) 
		
		# BahdanauAttention layer to process hidden
		self.W2 = tf.keras.layers.Dense(hidden_units)

		# BahdanauAttention layer to generate context vector from embedded input and hidden state
		self.V = tf.keras.layers.Dense(1)

		# Could not find how to choose the "teacher_force" option for the LSTM, I am assuming
		# that is how it generates the hidden states over the sequence.
		# 
		# We also use a grid of 64 LSTMs to process the indiviual image blocks. The weights
		# of the LSTMs are the same. We implement this by passing the 64 inputs as
		# a "batch" into a single LSTM, so the batch size is not the default "BATCH_SIZE", which is 1
		# Note LSTM expects a 3D tensor (batch_size, seq_length, feature)
		self.LSTM1 = tf.keras.layers.LSTM(self.hidden_units,
										 batch_input_shape= (seq_length, batch_input_shape, input_shape),
										 time_major = True, #(timesteps, batch, ...)
										 # input_shape= (seq_length, input_shape),
										 return_sequences=True,
										 return_state=True, # return hidden state
										 stateful= statefull_lstm_flag)
		
		self.LSTM2 = tf.keras.layers.LSTM(self.hidden_units,
										 batch_input_shape= (seq_length, batch_input_shape, input_shape),
										 time_major = True, #(timesteps, batch, ...)
										 # input_shape= (seq_length, input_shape),
										 return_sequences=True,
										 return_state=True, # return hidden state
										 stateful= statefull_lstm_flag) 
		
		self.LSTM3 = tf.keras.layers.LSTM(self.hidden_units,
										 batch_input_shape= (seq_length, batch_input_shape, input_shape),
										 time_major = True, #(timesteps, batch, ...)
										 # input_shape= (seq_length, input_shape),
										 return_sequences=True,
										 return_state=True, # return hidden state
										 stateful= statefull_lstm_flag)	   
		
	def call(self, x): 
		# Dimension of x is [seq_length, attention_shape=64,  hidden_units] and is hidden_state is [attention_shape=64, hidden_units]

		# print ('In RNN Decoder x=', x.shape, 'hidden=', hidden_state.shape)

		# Bahadanou attention -- note we have hooks for temporal attention too.
				
		if (len(self.hidden_state.shape) == 2):
		  hidden_with_time_axis = tf.expand_dims(self.hidden_state, 0)
		else :
		  print ('Error: hidden_state should be 2 dimensional. It is:', hidden_state.shape)
		  hidden_with_time_axis = self.hidden_state
		
		# score shape == (seq_length, attention_shape=64, hidden_units)
		score = tf.nn.tanh(self.W1(x) + self.W2(hidden_with_time_axis))
		
		# attention_weights shape == (seq_length, attention_shape=64, 1)
		# you get 1 at the last axis because you are applying score to self.V
		attention_weights = tf.nn.softmax(self.V(score), axis=1)
		
		# context_vector shape == (seq_length, attention_shape=64, hidden_units)
		context_vector = tf.multiply(x, attention_weights)
		
		#print ('context_vector=', context_vector.shape, 'attention_weights=', attention_weights.shape)
		
		# option 1: concatenate context vector with input x - very large state vector
		# shape after concatenation == (attention_shape=64, 1, embedding_dim + hidden_units)	
		# x_hat = tf.concat([context_vector, x], axis=-1)
		
		x_hat = context_vector  # (seq_length, attention_shape=64, embedding_dim)

		# LSTM expects a 3D tensor (seq_length, batch_size,  feature) since time_major == True
		# we use batch_size = 64 -- the 64 blocks of inceptionV3 features
		# seq_length, and feature = 2048 inceptionV3 features

		#  output, next_hidden_state, cell_state = self.LSTM (x_hat)
	 
		encoder_output1, _ , _ = self.LSTM1 (x_hat)
		encoder_output2, _ , _ = self.LSTM2 (encoder_output1)
		output, next_hidden_state, cell_state = self.LSTM3 (encoder_output2)

		# model.add(LSTM(100, activation='relu', input_shape=(n_in,1)))
		# model.add(RepeatVector(n_in))
		# model.add(LSTM(100, activation='relu', return_sequences=True))
		# model.add(TimeDistributed(Dense(1)))
		# model.compile(optimizer='adam', loss='mse')

		self.hidden_state = next_hidden_state

		#print ('x =', x_hat.shape, 'output=', output.shape, 'h state=', next_hidden_state.shape, 'cell state=', cell_state.shape)			   
			   
		return output, self.hidden_state, attention_weights

 
	def reset_hidden_state(self):
		self.hidden_state = tf.zeros((attention_shape, self.hidden_units))
		# LSTM expects a 3D tensor (batch_size, seq_length, feature)
		# we use batch_size = 64 (attention_shape) -- the 64 blocks of inceptionV3 features
		# seq_length, and feature = 2048 inceptionV3 features
		# hidden state dimension is (batch_size=attention_shape, features)

learnError = 0
@tf.function
def loss_function(target, pred, input_seq):  #Dimesions: [seq_length, 64, 2048]
  
	pred_loss = tf.square(tf.subtract(target, pred))
	
	# if we were to just do zero order hold as prediction, this is the loss or error
	frame_diff = tf.square(tf.subtract(target, input_seq)) * 0.5
	
	# prediction loss weighted by frame diffeence (zero-order hold difference), errors will be
	# weighted high for blocks with motion/change
	weighted_loss = tf.multiply(frame_diff, pred_loss) 

	sseLoss = tf.reduce_mean(weighted_loss)/(14*14*512)

	# weighted_loss = pred_loss

	# sseLoss = tf.reduce_mean(weighted_loss)#/(14*14*512)
	
	lossGrid = tf.nn.softmax(tf.reduce_mean(weighted_loss, 2), axis=1)
	
	return sseLoss, lossGrid

jsonData = json.load(open(sys.argv[1]))
vidPath = sys.argv[2]
modelPath = sys.argv[3]
outputPath = sys.argv[4]

scope = 'vgg_16'
fc_conv_padding = 'VALID'
dropout_keep_prob=0.7
is_training = False

inputs = tf.placeholder(tf.float32, (None, 224, 224, 3), name='inputs')
learning_rate = tf.placeholder(tf.float32, [])

r, g, b = tf.split(axis=3, num_or_size_splits=3, value=inputs * 255.0)
VGG_MEAN = [103.939, 116.779, 123.68]
VGG_inputs = tf.concat(values=[b - VGG_MEAN[0], g - VGG_MEAN[1], r - VGG_MEAN[2]], axis=3)

with tf.variable_scope(scope, 'vgg_16', [VGG_inputs]) as sc:
	end_points_collection = sc.original_name_scope + '_end_points'
	# Collect outputs for conv2d, fully_connected and max_pool2d.
	with slim.arg_scope([slim.conv2d, slim.fully_connected, slim.max_pool2d],
											outputs_collections=end_points_collection):
		net = slim.repeat(inputs, 2, slim.conv2d, 64, [3, 3], scope='conv1', trainable=False)
		net = slim.max_pool2d(net, [2, 2], scope='pool1') #112
		net = slim.repeat(net, 2, slim.conv2d, 128, [3, 3], scope='conv2', trainable=False)
		net = slim.max_pool2d(net, [2, 2], scope='pool2') #56
		net = slim.repeat(net, 3, slim.conv2d, 256, [3, 3], scope='conv3', trainable=False)
		net = slim.max_pool2d(net, [2, 2], scope='pool3') #28
		net = slim.repeat(net, 3, slim.conv2d, 512, [3, 3], scope='conv4', trainable=False)
		net = slim.max_pool2d(net, [2, 2], scope='pool4') #14
		conv4 = net
		net = slim.repeat(net, 3, slim.conv2d, 512, [3, 3], scope='conv5', trainable=False)
		net = slim.max_pool2d(net, [2, 2], scope='pool5') #7
		conv5 = net
		# Use conv2d instead of fully_connected layers.
		net = slim.conv2d(net, 4096, [7, 7], padding=fc_conv_padding, scope='fc6', trainable=False)
		net = slim.dropout(net, dropout_keep_prob, is_training=is_training,
											 scope='dropout6')
		net = slim.conv2d(net, 4096, [1, 1], scope='fc7', trainable=False)
		vgg16_Features = tf.reshape(net, (-1,4096))
		# Convert end_points_collection into a end_point dict.
		end_points = slim.utils.convert_collection_to_dict(end_points_collection)

vgg16_Features = tf.reshape(conv4, (-1, 196, 512))
# Setup LSTM

predictModel = RNN_Predictor (batch_input_shape=attention_shape, input_shape=feature_size, hidden_units=n_hidden1)

input_sequence = tf.reshape(vgg16_Features[0,...], (-1, 196, 512))
predictions, hidden, attention_weights = predictModel(input_sequence)

loss, loss_grid = loss_function(tf.reshape(vgg16_Features[1,...], (-1, 196, 512)), predictions, input_sequence)

feats = tf.keras.layers.GlobalAveragePooling1D()(hidden * predictions)

# Optimization
train_op = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)

batch = loadData(jsonData, vidPath)

#####################
### Training loop ###
#####################

init = tf.global_variables_initializer()

saver = tf.train.Saver(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope="vgg_16"))
with tf.Session() as sess:
	# Initialize parameters
	sess.run(init)
	saver.restore(sess, "./vgg_16.ckpt")
	saver = tf.train.Saver(max_to_keep=0)
	avgPredError = 1.0

	### In case of interruption, load parameters from the last iteration (ex: 29)
	saver.restore(sess, modelPath)
	### And update the loop to account for the previous iterations
	#for i in range(29,n_epochs):
	step = 0

	# LSTM
	if not os.path.exists(outputPath):
		os.makedirs(outputPath)

	new_state = np.random.uniform(-0.5,high=0.5,size=(1, attention_shape, 2*n_hidden1))
	for i in range(n_epochs):
		# Run 1 epoch
		loss1 = []
		shuffle(batch)

		for miniBatchPath in batch:
			# LSTM
			new_state = np.random.uniform(-0.5,high=0.5,size=(1, attention_shape, 2*n_hidden1))

			lr = lr_init

			avgPredError = 0
			vidPath, minibatches = loadMiniBatch(miniBatchPath)

			segCount = 0
			predError = collections.deque(maxlen=30)
			outfileName = '_'.join(vidPath.split(os.sep)[-3:-1]) + '.txt'
			outFile = os.path.join(outputPath, outfileName)
			featFile = os.path.join(outputPath, "features.txt")
			print(vidPath, outFile)
			features = []
			with open(outFile, 'w') as of:
				for x_train in minibatches:
					segCount += 1
					ret = sess.run([feats, loss, loss_grid, attention_weights], feed_dict = {inputs: x_train, learning_rate:lr})
					# new_state = ret[3]
					curr_attn = np.reshape(ret[-1], (-1, 14, 14))[0]
					features.append(ret[0])
					# plt.figure()
					# img = x_train[0]
					# plt.subplot(1,2,1)
					# plt.imshow(img)
					# plt.subplot(1,2,2)
					# plt.imshow(curr_attn, cmap='jet')
					# # plt.show(block=False)
					# # plt.pause(1)
					# # plt.close()
					# plt.savefig('temp_%d.png'%segCount)
					if ret[1]/avgPredError > 1.5:
					 	lr = lr / 10.
					else:
					 	lr = lr_init
					predError.append(ret[1])
					avgPredError = np.mean(predError)
					loss1.append(ret[1])
					# print('\r', ret[1], end="")

					a = np.reshape(ret[-1], (-1, 14, 14, 1))
					_, y_pred, x_pred, _ = np.unravel_index(np.argmax(a, axis=None), a.shape)
					of.write("%d\t%d\t%d\t%d\t%d\n"%(segCount, 0, y_pred, x_pred, 0))
					# print(np.unravel_index(np.argmax(a, axis=None), a.shape))
					# print(y_pred, x_pred)
					# print(miniBatchPath[0])
					# if segCount > 1:
					# 	sys.exit(0)
				with open(featFile, 'a') as ff:
					ff.write("%s\t%s\n"%(outfileName.replace(".txt", ""), ','.join([str(m) for m in np.amax(np.vstack(features), axis=0).tolist()])))
				# sys.exit(0)
			