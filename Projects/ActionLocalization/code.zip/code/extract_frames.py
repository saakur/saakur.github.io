import sys, os, cv2, json
import numpy as np
from shutil import copyfile

def extractUCF_Sports(jsonFile, inputPath):
	with open(jsonFile, 'rb') as jsonF:
		data = json.load(jsonF)
		for split in ["train_path", "test_path"]:
			vidPaths = data[split]
			for vidpath1 in vidPaths:
				vidPath = os.path.join(inputPath, vidpath1)
				if os.path.exists(vidPath):

					vidName = os.path.basename(vidPath).split('.')[0]
					
					outputDir = os.path.join(os.path.dirname(vidPath), "frames")

					if not os.path.exists(outputDir):
						os.makedirs(outputDir)
					elif len(os.listdir(outputDir)) <= 5:
						print(print("Found video - %s, %s, %s"%(vidPath, vidName, outputDir)))
						jpgFiles = sorted([x for x in os.listdir((os.sep).join(vidPath.split(os.sep)[:-1])) if x.endswith('jpg')], key=lambda x: int(x.split('/')[-1].split('.')[0].split('_')[-1]))
						i = 1
						for jpgFile in jpgFiles:
							copyfile(os.path.join((os.sep).join(vidPath.split(os.sep)[:-1]), jpgFile), os.path.join(outputDir, '%05d.jpg'%i))
							i += 1
						print(jpgFiles)
					else:
						continue
						vidcap = cv2.VideoCapture(vidPath)
						success,image = vidcap.read()
						count = 0
						while success:
							cv2.imwrite("%s.jpg" % os.path.join(outputDir, '%05d'%(count)), image)     # save frame as JPEG file      
							success,image = vidcap.read()
							count += 1
				else:
					
					outputDir = os.path.join(os.path.dirname(vidPath), "frames")
					if not os.path.exists(outputDir):
						print("Not found - %s"%vidPath)
						os.makedirs(outputDir)
					elif len(os.listdir(outputDir)) <= 5:
						jpgFiles = sorted([x for x in os.listdir((os.sep).join(vidPath.split(os.sep)[:-1])) if x.endswith('jpg')], key=lambda x: int(x.split('/')[-1].split('.')[0].split('_')[-1]))
						i = 1
						for jpgFile in jpgFiles:
							copyfile(os.path.join((os.sep).join(vidPath.split(os.sep)[:-1]), jpgFile), os.path.join(outputDir, '%05d.jpg'%i))
							i += 1
						print(jpgFiles)

	return None

def verifyUCF_Sports(jsonFile, inputPath):
	with open(jsonFile, 'rb') as jsonF:
		data = json.load(jsonF)
		for split in ["train_path", "test_path"]:
			vidPaths = data[split]
			for vidpath1 in vidPaths:
				vidPath = os.path.join(inputPath, vidpath1)
				vidName = os.path.basename(vidPath).split('.')[0]
				outputDir = os.path.join(os.path.dirname(vidPath), "frames")
				if len(os.listdir(outputDir)) <= 5:
					print(print("Found video - %s, %s, %s"%(vidPath, vidName, outputDir)))

def extractJHMDB(jsonFile, inputPath):
	with open(jsonFile, 'rb') as jsonF:
		data = json.load(jsonF)["1"]
		for split in ["train_path", "test_path"]:
			vidPaths = data[split]
			for vidpath1 in vidPaths:
				vidPath = os.path.join(inputPath, vidpath1)
				if os.path.exists(vidPath):

					vidName = os.path.basename(vidPath).split('.')[0]
					
					outputDir = os.path.join(os.path.dirname(vidPath), vidName, "frames")

					if not os.path.exists(outputDir):
						os.makedirs(outputDir)
					vidcap = cv2.VideoCapture(vidPath)
					success,image = vidcap.read()
					count = 0
					while success:
						cv2.imwrite("%s.jpg" % os.path.join(outputDir, '%05d'%(count)), image)     # save frame as JPEG file      
						success,image = vidcap.read()
						count += 1
				else:
					print("Not found - %s"%vidPath)
					
	return None

def extractGTEA(jsonFile, inputPath):
	with open(jsonFile, 'rb') as jsonF:
		data = json.load(jsonF)
		for split in ["train_path", "test_path"]:
			vidPaths = data[split]
			for vidpath1 in vidPaths:
				vidPath = os.path.join(inputPath, vidpath1)
				if os.path.exists(vidPath):

					vidName = os.path.basename(vidPath).split('.')[0]
					
					outputDir = os.path.join(os.path.dirname(vidPath), "Frames", vidName)

					if not os.path.exists(outputDir):
						os.makedirs(outputDir)
					vidcap = cv2.VideoCapture(vidPath)
					success,image = vidcap.read()
					count = 0
					while success:
						cv2.imwrite("%s.jpg" % os.path.join(outputDir, '%05d'%(count)), image)     # save frame as JPEG file      
						success,image = vidcap.read()
						count += 1
				else:
					print("Not found - %s"%vidPath)
	return None
jsonFile = sys.argv[1]
dataset = sys.argv[2]
inputDir = sys.argv[3]

if dataset == "UCF-Sports":
	print("Extacting Frames for UCF Sports")
	extractUCF_Sports(jsonFile, inputDir)
	print("Completed Extraction")
	verifyUCF_Sports(jsonFile, inputDir)
elif dataset == "JHMDB":
	print("Extacting Frames for JHMDB")
	extractJHMDB(jsonFile, inputDir)
	print("Completed Extraction")
elif dataset == "GTEA":
	print("Extacting Frames for GTEA")
	extractGTEA(jsonFile, inputDir)
	print("Completed Extraction")
else:
	print("Unimplemented Extraction Dataset! Aborting...")
	sys.exit(-1)
